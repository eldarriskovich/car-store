package com.example.carstore;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {


    public SQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public void queryData(String sql) {
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }

    public void insertData(byte[] image, String brand, String model, String year, String price) {
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO FOOD VALUES (NULL, ?, ?, ?, ?, ?)";

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();

        statement.bindBlob(1, image);
        statement.bindString(2, brand);
        statement.bindString(3, model);
        statement.bindString(4, year);
        statement.bindString(5, price);

        statement.executeInsert();
    }

    public Cursor getData(String sql) {
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    public int deleteorder(byte[] image) {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete("FOOD", "image=" + image, null);
    }


    /*public ArrayList<model> getcars(){

        ArrayList<model> orders= new ArrayList<>();
        SQLiteDatabase db= this.getWritableDatabase();

        Cursor cursor= db.rawQuery("Select image,brand,model,year,price from FOOD",null);
        if (cursor.moveToFirst()){
            while (cursor.moveToNext()) {
                model model = new model();
                model.setImage(cursor.getBlob(0));
                model.setBrand(cursor.getString(1));
                model.setModel(cursor.getString(2));
                model.setYear(cursor.getString(3));
                model.setPrice(cursor.getString(4));

                orders.add(model);
            }
        }
        cursor.close();
        db.close();
        return orders;
    }*/


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}