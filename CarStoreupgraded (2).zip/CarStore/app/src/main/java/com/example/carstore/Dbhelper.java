package com.example.carstore;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Dbhelper extends SQLiteOpenHelper {

    final static String DBNAME="mydatabase";

    public Dbhelper(@Nullable Context context) {
        super(context, DBNAME, null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

       /* String qry = "create table tbl_car ( id integer primary key autoincrement, image BLOG, brand text, model text, year text, price text)";

        sqLiteDatabase.execSQL(qry);*/



    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String qry= "DROP TABLE IF EXISTS tbl_car";
        sqLiteDatabase.execSQL(qry);
        onCreate(sqLiteDatabase);

    }
    /*public long addrecord(byte[] image,String brand,String model,String year,String price){

        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues cv= new ContentValues();
        cv.put("image",image);
        cv.put("brand",brand);
        cv.put("mod el",model);
        cv.put("year",year);
        cv.put("price",price);

        long res= db.insert("tbl_car",null,cv);

        db.close();
        return res;
    }*/
    public void queryData(String sql){
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }


    public void insertData(byte[] image, String brand,String model,String year, String price){
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO FOOD VALUES (NULL, ?, ?, ?)";

        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();

        statement.bindBlob(1, image);
        statement.bindString(2, brand);
        statement.bindString(3, model);
        statement.bindString(3, year);
        statement.bindString(3, price);

        statement.executeInsert();
    }


/*
    public ArrayList<model> getcars(){

        ArrayList<model> orders= new ArrayList<>();
        SQLiteDatabase db= this.getWritableDatabase();

        Cursor cursor= db.rawQuery("Select image,brand,model,year,price from tbl_car",null);
        if (cursor.moveToFirst()){
            while (cursor.moveToNext()) {
                model model = new model();
                model.setImage(cursor.getBlob(0));
                model.setBrand(cursor.getString(1));
                model.setModel(cursor.getString(2));
                model.setYear(cursor.getString(3));
                model.setPrice(cursor.getString(4));

                orders.add(model);
            }
        }
        cursor.close();
        db.close();
        return orders;
    }
*/
}
