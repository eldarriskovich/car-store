package com.example.carstore;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class detailistadpater extends RecyclerView.Adapter<detailistadpater.viewholder>{


    ArrayList<model> list;
    Context context;
    int singledata;
    SQLiteDatabase sqLiteDatabase;

    public detailistadpater(ArrayList<model> list, Context context, int singledata, SQLiteDatabase sqLiteDatabase) {
        this.list = list;
        this.context = context;
        this.singledata = singledata;
        this.sqLiteDatabase = sqLiteDatabase;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.detaillist,parent,false);

        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, @SuppressLint("RecyclerView") int position) {

        model model= list.get(position);

        byte[] image=list.get(position).getImage();
        Bitmap bitmap= BitmapFactory.decodeByteArray(image,0,image.length);

        holder.imageView.setImageBitmap(bitmap);
        holder.t1.setText(list.get(position).getBrand());
        holder.t2.setText(list.get(position).getModel());
        holder.t3.setText(list.get(position).getYear());
        holder.t4.setText(list.get(position).getPrice());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(context,cardetail.class);
                intent.putExtra("im",bitmap);
                intent.putExtra("branddetail", String.valueOf(list.get(position).getBrand()));
                intent.putExtra("modeldetail",String.valueOf(list.get(position).getModel()));
                intent.putExtra("yeardetail",String.valueOf(list.get(position).getYear()));
                intent.putExtra("pricedetail",String.valueOf(list.get(position).getPrice()));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
/*
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                PopupMenu popupMenu= new PopupMenu(context,view);
                popupMenu.inflate(R.menu.flowmenu);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {

                        switch (menuItem.getItemId()){
                            case R.menu.flowmenu:

                                SQLiteHelper sqLiteHelper= new SQLiteHelper(context, "FoodDB.sqlite", null, 2);

                                sqLiteDatabase=sqLiteHelper.getReadableDatabase();
                                long rec =sqLiteDatabase.delete("FOOD","image="+model.getImage(),null);
                                if(rec!=-1)
                                {
                                    Toast.makeText(context, "Data Deleted", Toast.LENGTH_SHORT).show();
                                list.remove(holder.getAdapterPosition());
                                notifyDataSetChanged();
                                }
                        break;
                            default: return false;
                        }
                        return false;
                    }
                });
                return false;
            }
        });
*/
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class viewholder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView t1,t2,t3,t4;

        public viewholder(@NonNull View itemView) {
            super(itemView);

            imageView= itemView.findViewById(R.id.imgdetail);
            t1= itemView.findViewById(R.id.cname);
            t2= itemView.findViewById(R.id.cmodel);
            t3= itemView.findViewById(R.id.cyear);
            t4= itemView.findViewById(R.id.cprice);


        }
    }
}
