package com.example.carstore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;

public class carlist extends AppCompatActivity {

    FloatingActionButton button;
    RecyclerView recyclerView;
    listadaptr listadaptr;
    SQLiteDatabase sqLiteDatabase;
    SQLiteHelper dbhelper;
    ArrayList<model> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carlist);

        button = findViewById(R.id.fabutton);
        recyclerView = findViewById(R.id.recview);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        list = new ArrayList<>();

        list.add(new model(null,"bmw","22","22","22"));
        listadaptr= new listadaptr(list,this,R.layout.carlistitem,sqLiteDatabase);
        dbhelper = new SQLiteHelper(this, "FoodDB", null, 2);
        recyclerView.setAdapter(listadaptr);
        displaydata();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(carlist.this, Addcar.class));
            }
        });

    }

    private void displaydata() {

        sqLiteDatabase = dbhelper.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from FOOD", null);
        ArrayList<model> models = new ArrayList<>();
        while (cursor.moveToNext()) {
            byte[] image = cursor.getBlob(1);
            String brand = cursor.getString(2);
            String model = cursor.getString(3);
            String year = cursor.getString(4);
            String price = cursor.getString(5);
            models.addAll(Collections.singleton(new model(image, brand, model, year, price)));
        }
        cursor.close();
        sqLiteDatabase.close();
        listadaptr = new listadaptr(models, this, R.layout.carlistitem, sqLiteDatabase);
        recyclerView.setAdapter(listadaptr);
        listadaptr.notifyDataSetChanged();

    }

    ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT | ItemTouchHelper.DOWN | ItemTouchHelper.UP) {

        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
            Toast.makeText(carlist.this, "on Move", Toast.LENGTH_SHORT).show();
            return false;
        }

        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
            Toast.makeText(carlist.this, "on Swiped ", Toast.LENGTH_SHORT).show();
            //Remove swiped item from list and notify the RecyclerView
            int position = viewHolder.getAdapterPosition();
            list.remove(position);
            listadaptr.notifyItemRemoved(position);
            listadaptr.notifyDataSetChanged();

        }
    };
}