package com.example.carstore;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class cardetail extends AppCompatActivity {

    ImageView imgview;
    TextView t1,t2,t3,t4;
    RecyclerView rec;
    SQLiteDatabase sqLiteDatabase;
    SQLiteHelper dbhelper;
    detailistadpater listadaptr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardetail);




        imgview=findViewById(R.id.imgdetail);
        rec=findViewById(R.id.reclist);
        t1=findViewById(R.id.cname);
        t2=findViewById(R.id.cmodel);
        t3=findViewById(R.id.cyear);
        t4=findViewById(R.id.cprice);


        rec.setLayoutManager(new LinearLayoutManager(this));


        dbhelper= new SQLiteHelper(this,"FoodDB",null,2);

        displaydata();

           /* byte[] bytespp = getIntent().getByteArrayExtra("im" );

            Bitmap bitmap = convert(bytespp);
            imgview.setImageBitmap(bitmap);*/
/*
        Bitmap bitmap=(Bitmap)this.getIntent().getParcelableExtra("im");
        imgview.setImageBitmap(bitmap);

        t1.setText(getIntent().getStringExtra("branddetail"));
        t2.setText(getIntent().getStringExtra("modeldetail"));
        t3.setText(getIntent().getStringExtra("yeardetail"));
        t4.setText(getIntent().getStringExtra("pricedetail"));*/

    }
    private void displaydata() {

        sqLiteDatabase= dbhelper.getReadableDatabase();
        Cursor cursor= sqLiteDatabase.rawQuery("select * from FOOD",null);
        ArrayList<model> models= new ArrayList<>();
        while (cursor.moveToNext()){
            byte[]image=cursor.getBlob(1);
            String brand=cursor.getString(2);
            String model=cursor.getString(3);
            String year=cursor.getString(4);
            String price=cursor.getString(5);
            models.addAll(Collections.singleton(new model(image, brand, model, year, price)));
        }
        cursor.close();
        sqLiteDatabase.close();
        listadaptr= new detailistadpater(models,this,R.layout.carlistitem,sqLiteDatabase);
        rec.setAdapter(listadaptr);
        listadaptr.notifyDataSetChanged();

    }


    private Bitmap convert(byte[] bytes){
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}